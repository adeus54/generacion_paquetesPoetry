# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['t_converter_na']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 't-converter-na',
    'version': '0.0.1',
    'description': 'This tool is a demostration how to convert the temperatures beteween Celsius, Fahrenheit, Kelvin and Rankine',
    'long_description': None,
    'author': 'Alex Aranda',
    'author_email': 'alexarand32@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.6,<4.0',
}


setup(**setup_kwargs)
