# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['t_converter_na']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 't-converter-na',
    'version': '0.1.0',
    'description': 'This tool is a demostration how to convert the temperatures beteween Celsius, Fahrenheit, Kelvin and Rankine',
    'long_description': '# Temperature Convert\n \nThis tool convert the temperatures beteween Celsius, Fahrenheit, Kelvin and Rankine.\n \n## Instalation \n \nFrom testpypi\n~~~\npip install -i https://test.pypi.org/simple/ t-converter-na==0.0.1\n~~~\n \n## How to use it\n \n~~~\n# Para invocar la libreria use\nfrom t_converter_na import convertions as cvt\n\n# Cree un objeto de alguna de las clases de Temperatura\nfharenheit = cvt.Fahrenheit()\ncelcius = cvt.Celsius()\n\n# Para transformar use los metodos que tiene la clase.\nfharenheit.F_to_K(50)\n~~~\n',
    'author': 'Alex Aranda',
    'author_email': 'alexarand32@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/adeus54/generacion_paquetesPoetry',
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.6,<4.0',
}


setup(**setup_kwargs)
